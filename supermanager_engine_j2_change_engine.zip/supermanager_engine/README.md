# SuperManager ACB 2026/27 · Motor J2

## Corrección importante de presupuesto

Los 5.000.000 € son el presupuesto inicial. Una vez disputada una jornada, el equipo puede valer más de 5 M gracias al broker. Por tanto, el motor **no** impone `valor_plantilla <= 5 M` en cada jornada.

Para un movimiento calcula:

`caja_final = caja_actual + precio_salidas - precio_entradas`

y exige `caja_final >= 0`.

## Flujo

1. Ingesta de Rincón.
2. Normalización y estatus JFL/EXT.
3. Snapshot auditable.
4. Predicción J2.
5. Analizar el equipo actual.
6. Probar 0, 1, 2, 3 y 4 cambios.
7. Validar posición, JFL, EXT, bajas, bloqueos y caja.
8. Generar recomendación principal + alternativas.
9. Publicar JSON para la futura app Android.

## Fuente

Rincón del Manager se presenta como elaborado a partir de datos oficiales ACB. Sus previsiones combinan media de temporada, últimas cinco jornadas y partido de ida, ajustadas por dificultad del rival y posición. Es una señal de entrada, no el resultado final del motor.

## Equipo real

Copia `data/current_team_template.json` a `data/current_team.json` y sustituye los jugadores y la caja. No rellenes JFL/EXT a mano si la fuente oficial todavía no ha sido verificada.
