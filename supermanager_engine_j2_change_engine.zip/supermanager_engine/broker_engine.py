def projected_price(current_price, accumulated_sm, projected_sm, games):
    # Precio teórico según la media acumulada y la valoración proyectada.
    # El límite de variación es ±15%.
    target = 50_000 * ((accumulated_sm + projected_sm) / (games + 1))
    return min(current_price * 1.15, max(current_price * 0.85, target))

def projected_broker(current_price, accumulated_sm, projected_sm, games):
    return projected_price(
        current_price,
        accumulated_sm,
        projected_sm,
        games
    ) - current_price
