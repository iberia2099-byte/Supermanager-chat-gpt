def project_player(player_data):
    # Punto de entrada para el modelo real.
    # Por ahora utiliza valores ya calculados en players.json.
    return {
        "projected_sm": float(player_data.get("projected_sm", 0)),
        "projected_broker": float(player_data.get("projected_broker", 0)),
        "confidence": float(player_data.get("confidence", 0)),
        "risk": float(player_data.get("risk", 100)),
    }
