BUDGET = 5_000_000
MAX_CHANGES = 4
MIN_JFL = 4
MAX_EXTRA = 2

POSITION_COUNTS = {
    "B": 2,
    "A": 4,
    "P": 4,
}

# Pesos iniciales. Se calibrarán con backtesting.
WEIGHTS = {
    "points": 1.00,
    "broker": 0.000002,
    "confidence": 0.15,
    "risk": 0.15,
    "change_cost": 2.0,
}
