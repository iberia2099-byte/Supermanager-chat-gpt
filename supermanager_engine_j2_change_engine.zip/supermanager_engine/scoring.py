from config import WEIGHTS
from models import Team

def team_score(team: Team, changes: int = 0):
    return (
        WEIGHTS["points"] * team.projected_sm
        + WEIGHTS["broker"] * team.projected_broker
        + WEIGHTS["confidence"] * team.confidence
        - WEIGHTS["risk"] * team.risk
        - WEIGHTS["change_cost"] * changes
    )

def player_score(player):
    return (
        player.projected_sm
        + WEIGHTS["broker"] * player.projected_broker
        + WEIGHTS["confidence"] * player.confidence
        - WEIGHTS["risk"] * player.risk
    )
