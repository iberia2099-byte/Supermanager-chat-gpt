import json
from models import Player, Team
from change_optimizer import optimize
from recommendation_engine import choose_recommendations, format_recommendation

def load_players():
    with open("data/players.json", encoding="utf-8") as f:
        raw = json.load(f)
    return [Player(**x) for x in raw]

def load_team(players_by_id):
    with open("data/current_team.json", encoding="utf-8") as f:
        raw = json.load(f)

    players = [players_by_id[x["id"]] for x in raw["players"]]
    return Team(players=players, cash=raw.get("cash", 0))

def main():
    players = load_players()
    by_id = {p.id: p for p in players}
    team = load_team(by_id)

    recommendations = optimize(team, players)
    result = choose_recommendations(recommendations)

    print("\n=== SUPERMANAGER ACB 2026-27 ===")
    print("=== RECOMENDACIÓN J2 ===\n")

    if result["main"] is None:
        print("No existe un equipo legal con los datos actuales.")
        return

    print(format_recommendation(result["main"]))

    if result["alternatives"]:
        print("\n=== ALTERNATIVAS ===")
        for i, alt in enumerate(result["alternatives"], 1):
            print(f"\n--- Alternativa {i} ---")
            print(format_recommendation(alt))

if __name__ == "__main__":
    main()
