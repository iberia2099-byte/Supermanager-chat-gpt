from models import Recommendation

def choose_recommendations(candidates):
    if not candidates:
        return {"status": "NO_VALID_TEAM", "main": None, "alternatives": []}

    main = candidates[0]

    # Evitar devolver cinco equipos prácticamente iguales.
    selected = []
    for candidate in candidates:
        overlap = set(p.id for p in candidate.team.players)
        too_similar = False

        for previous in selected:
            prev_ids = set(p.id for p in previous.team.players)
            common = len(overlap & prev_ids)
            if common >= 9:
                too_similar = True
                break

        if not too_similar:
            selected.append(candidate)

        if len(selected) == 3:
            break

    return {
        "status": "OK",
        "main": selected[0],
        "alternatives": selected[1:]
    }

def format_recommendation(rec: Recommendation):
    if rec is None:
        return "No hay recomendación válida."

    lines = [
        f"CAMBIOS: {len(rec.changes)}",
        f"Valor plantilla: {rec.team.roster_value:,} €",
        f"SM previsto: {rec.team.projected_sm:.2f}",
        f"Broker previsto: {rec.team.projected_broker:+,.0f} €",
        f"Confianza: {rec.team.confidence:.1f}",
        f"Riesgo: {rec.team.risk:.1f}",
        ""
    ]

    for change in rec.changes:
        lines.append(
            f"SALE  {change.out_player.name} ({change.out_player.price:,} €)"
        )
        lines.append(
            f"ENTRA {change.in_player.name} ({change.in_player.price:,} €)"
        )
        lines.append("")

    if not rec.changes:
        lines.append("NO HACER CAMBIOS")

    return "\n".join(lines)
