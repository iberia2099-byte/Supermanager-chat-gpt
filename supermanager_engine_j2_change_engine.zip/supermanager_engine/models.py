from dataclasses import dataclass, field
from typing import List

@dataclass
class Player:
    id: str
    name: str
    position: str
    price: int
    jfl: bool
    extra: bool
    projected_sm: float = 0.0
    projected_broker: float = 0.0
    confidence: float = 0.0
    risk: float = 0.0
    available: bool = True
    match_locked: bool = False
    injured: bool = False
    explanation: str = ""
    source: str = ""
    team: str = ""

@dataclass
class Team:
    players: List[Player]
    # Caja libre. El patrimonio total = jugadores + caja.
    # Tras J1 puede superar 5 M gracias al broker.
    cash: int = 0

    @property
    def total_value(self):
        return sum(p.price for p in self.players) + self.cash

    @property
    def roster_value(self):
        return sum(p.price for p in self.players)

    @property
    def projected_sm(self):
        return sum(p.projected_sm for p in self.players)

    @property
    def projected_broker(self):
        return sum(p.projected_broker for p in self.players)

    @property
    def confidence(self):
        return sum(p.confidence for p in self.players) / len(self.players) if self.players else 0

    @property
    def risk(self):
        return sum(p.risk for p in self.players) / len(self.players) if self.players else 100

@dataclass
class Change:
    out_player: Player
    in_player: Player

@dataclass
class Recommendation:
    changes: List[Change]
    team: Team
    score: float
    reasons: List[str] = field(default_factory=list)
