"""
Ingestor Rincón del SuperManager.

Dependencias:
    pip install requests pandas lxml beautifulsoup4

Las URLs son configurables porque Rincón puede cambiar su estructura.
El ingestor guarda el HTML bruto y conserva los datos originales antes
de transformarlos al modelo interno.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re

import pandas as pd
import requests


BASE = "https://www.rincondelmanager.com/smgr"

URLS = {
    "home": f"{BASE}/",
    "predictions": f"{BASE}/previsiones.php",
    "broker": f"{BASE}/simulador_broker.php",
    "calendar": f"{BASE}/calendario.php",
    "difficulty": f"{BASE}/dificultad_calendario.php",
    "market": f"{BASE}/visualizacion_fichados.php",
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 SuperManagerACBResearch/1.0"
}


@dataclass
class Snapshot:
    source: str
    retrieved_at: str
    url: str
    sha256: str
    rows: int
    data: list[dict]


def get_html(url: str) -> tuple[str, str]:
    response = requests.get(url, headers=HEADERS, timeout=30)
    response.raise_for_status()
    response.encoding = response.apparent_encoding or "utf-8"
    html = response.text
    digest = hashlib.sha256(html.encode("utf-8")).hexdigest()
    return html, digest


def clean_number(value):
    if value is None:
        return None

    s = str(value).strip()
    if not s or s in {"—", "-", "nan", "NaN"}:
        return None

    # 322.000 € / 20,5 / -1,09 / +146.625 €
    s = s.replace("€", "").replace("%", "").strip()
    s = s.replace("+", "")

    if "," in s and "." in s:
        # European number: 1.234,56
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+", s):
        s = s.replace(".", "")

    try:
        return float(s)
    except ValueError:
        return value


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [
        re.sub(r"\s+", " ", str(c).strip()).lower()
        for c in df.columns
    ]
    return df


def read_tables(html: str) -> list[pd.DataFrame]:
    try:
        tables = pd.read_html(html)
    except ValueError:
        return []
    return [normalize_columns(t) for t in tables]


def find_table(tables, required_terms):
    for table in tables:
        columns = " ".join(map(str, table.columns))
        if all(term.lower() in columns for term in required_terms):
            return table
    return None


def fetch_predictions(round_number: int) -> Snapshot:
    url = f"{URLS['predictions']}?jornada={round_number}"
    html, digest = get_html(url)
    tables = read_tables(html)

    table = find_table(
        tables,
        ["jugador", "pos", "prev. sm", "precio"]
    )

    if table is None:
        raise RuntimeError(
            "No se encontró la tabla de previsiones. "
            "La estructura de Rincón puede haber cambiado."
        )

    records = []
    for row in table.to_dict("records"):
        records.append({
            "player_name": row.get("jugador"),
            "team": row.get("eq"),
            "position": row.get("pos"),
            "match": row.get("partido"),
            "projected_sm": clean_number(row.get("prev. sm")),
            "difficulty": row.get("dificultad"),
            "season_avg": clean_number(row.get("m.temp")),
            "last5": clean_number(row.get("últ.5")),
            "first_leg": clean_number(row.get("ida")),
            "opponent_season": row.get("rvl temp"),
            "opponent_last5": row.get("rvl últ5"),
            "price": clean_number(row.get("precio")),
            "games": clean_number(row.get("pj")),
        })

    return Snapshot(
        source="rincon_predictions",
        retrieved_at=datetime.now(timezone.utc).isoformat(),
        url=url,
        sha256=digest,
        rows=len(records),
        data=records,
    )


def fetch_home(round_number: int | None = None) -> Snapshot:
    html, digest = get_html(URLS["home"])
    tables = read_tables(html)

    records = []
    for idx, table in enumerate(tables):
        records.append({
            "table_index": idx,
            "columns": list(map(str, table.columns)),
            "rows": table.to_dict("records"),
        })

    return Snapshot(
        source="rincon_home",
        retrieved_at=datetime.now(timezone.utc).isoformat(),
        url=URLS["home"],
        sha256=digest,
        rows=len(records),
        data=records,
    )


def save_snapshot(snapshot: Snapshot, directory="snapshots"):
    path = Path(directory)
    path.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{snapshot.source}_{stamp}.json"

    output = path / filename
    output.write_text(
        json.dumps(asdict(snapshot), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return output


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--round", type=int, default=2)
    args = parser.parse_args()

    snapshot = fetch_predictions(args.round)
    output = save_snapshot(snapshot)

    print(f"Fuente: {snapshot.source}")
    print(f"Filas: {snapshot.rows}")
    print(f"SHA256: {snapshot.sha256}")
    print(f"Snapshot: {output}")
