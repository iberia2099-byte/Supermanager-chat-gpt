from __future__ import annotations

import json
from pathlib import Path

from ingestion.rincon import fetch_predictions, save_snapshot


def run_round(round_number: int):
    """
    Descarga la previsión de una jornada y crea un snapshot inmutable.
    """
    snapshot = fetch_predictions(round_number)
    path = save_snapshot(snapshot)

    print(f"[OK] J{round_number}: {snapshot.rows} jugadores")
    print(f"[OK] SHA256: {snapshot.sha256}")
    print(f"[OK] Snapshot: {path}")

    return snapshot


if __name__ == "__main__":
    run_round(2)
