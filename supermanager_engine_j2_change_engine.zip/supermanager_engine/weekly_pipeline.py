"""Pipeline semanal auditable para SuperManager ACB."""
import json
from datetime import datetime, timezone
from pathlib import Path

from ingestion.rincon import fetch_predictions, save_snapshot


def run(round_number: int):
    snapshot = fetch_predictions(round_number)
    snapshot_path = save_snapshot(snapshot)

    output = {
        "season": "2026-27",
        "round": round_number,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_snapshot": str(snapshot_path),
        "source_sha256": snapshot.sha256,
        "status": "INGESTED_ONLY",
        "next_step": "Cargar equipo actual y estatus JFL/EXT antes de optimizar cambios."
    }

    out_dir = Path("output")
    out_dir.mkdir(exist_ok=True)
    path = out_dir / f"jornada_{round_number}.json"
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] Pipeline J{round_number}: {path}")


if __name__ == "__main__":
    run(2)
