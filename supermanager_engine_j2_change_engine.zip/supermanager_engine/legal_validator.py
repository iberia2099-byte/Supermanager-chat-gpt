from config import POSITION_COUNTS, MIN_JFL, MAX_EXTRA
from models import Team, Player


def validate_roster(team: Team, require_complete: bool = True):
    """Valida la legalidad del equipo. No aplica el límite inicial de 5 M.

    Después de crear el equipo, el patrimonio puede superar 5 M gracias al broker.
    La restricción económica de un cambio se valida con la caja disponible.
    """
    errors = []

    if require_complete and len(team.players) != 10:
        errors.append(f"Equipo incompleto: {len(team.players)}/10 jugadores")

    for pos, required in POSITION_COUNTS.items():
        count = sum(p.position == pos for p in team.players)
        if count != required:
            errors.append(f"Posición {pos}: {count}/{required}")

    jfl = sum(p.jfl for p in team.players)
    if jfl < MIN_JFL:
        errors.append(f"JFL insuficientes: {jfl}/{MIN_JFL}")

    extra = sum(p.extra for p in team.players)
    if extra > MAX_EXTRA:
        errors.append(f"Extracomunitarios: {extra}/{MAX_EXTRA}")

    unavailable = [p.name for p in team.players if not p.available or p.injured]
    if unavailable:
        errors.append("Jugadores no disponibles: " + ", ".join(unavailable))

    if len({p.id for p in team.players}) != len(team.players):
        errors.append("Hay jugadores duplicados")

    if team.cash < 0:
        errors.append(f"Caja negativa: {team.cash:,} €")

    return len(errors) == 0, errors


def validate_team(team: Team):
    return validate_roster(team, require_complete=True)


def validate_trade(current_team: Team, outs: list[Player], ins: list[Player], max_changes: int = 4):
    errors = []

    if not (1 <= len(outs) == len(ins) <= max_changes):
        errors.append(f"Número de cambios no válido: {len(outs)}")
        return False, errors, current_team.cash

    if len({p.id for p in outs}) != len(outs) or len({p.id for p in ins}) != len(ins):
        errors.append("Hay jugadores repetidos en el movimiento")

    if any(p.id not in {x.id for x in current_team.players} for p in outs):
        errors.append("Se intenta vender un jugador que no está en el equipo")

    if any(not p.available or p.injured or p.match_locked for p in ins):
        errors.append("Hay una incorporación no disponible o bloqueada")

    if sorted(p.position for p in outs) != sorted(p.position for p in ins):
        errors.append("Los cambios no conservan la composición por posición")

    new_players = [p for p in current_team.players if p.id not in {x.id for x in outs}] + ins
    cash_after = current_team.cash + sum(p.price for p in outs) - sum(p.price for p in ins)
    new_team = Team(players=new_players, cash=cash_after)

    ok_roster, roster_errors = validate_roster(new_team, require_complete=True)
    errors.extend(roster_errors)

    return len(errors) == 0 and ok_roster, errors, cash_after
