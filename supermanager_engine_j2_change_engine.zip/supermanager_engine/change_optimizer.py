from itertools import combinations
from models import Team, Player, Change, Recommendation
from legal_validator import validate_team, validate_trade
from scoring import team_score
from config import MAX_CHANGES


def _pair_by_position(outs, ins):
    """Empareja entradas/salidas por posición, evitando zip arbitrario."""
    by_pos = {}
    for p in ins:
        by_pos.setdefault(p.position, []).append(p)
    changes = []
    for out in outs:
        bucket = by_pos.get(out.position, [])
        if not bucket:
            return None
        incoming = bucket.pop(0)
        changes.append(Change(out, incoming))
    return changes


def optimize(current_team: Team, market: list[Player], max_changes=MAX_CHANGES):
    candidates = []
    current_ids = {x.id for x in current_team.players}

    ok, _ = validate_team(current_team)
    if ok:
        candidates.append(Recommendation(
            changes=[], team=current_team,
            score=team_score(current_team, 0),
            reasons=["Mantener el equipo actual es una opción legal."]
        ))

    available = [
        p for p in market
        if p.id not in current_ids and p.available and not p.injured and not p.match_locked
    ]

    # No limitamos artificialmente a 30 antes de combinar: podría ocultar
    # una operación legal que sea mejor por precio/cupo/posición.
    for n in range(1, min(max_changes, len(current_team.players)) + 1):
        for outs in combinations(current_team.players, n):
            positions = sorted(p.position for p in outs)
            eligible = [p for p in available if p.position in positions]

            for ins in combinations(eligible, n):
                if sorted(p.position for p in ins) != positions:
                    continue

                valid, errors, cash_after = validate_trade(
                    current_team, list(outs), list(ins), max_changes=max_changes
                )
                if not valid:
                    continue

                new_players = [p for p in current_team.players if p.id not in {x.id for x in outs}] + list(ins)
                new_team = Team(players=new_players, cash=cash_after)
                changes = _pair_by_position(outs, ins)
                if changes is None:
                    continue

                score = team_score(new_team, n)
                reasons = [
                    f"{o.name} → {i.name}: {i.projected_sm - o.projected_sm:+.2f} SM previstos, "
                    f"{i.projected_broker - o.projected_broker:+,.0f} € broker."
                    for o, i in [(c.out_player, c.in_player) for c in changes]
                ]
                reasons.append(f"Caja tras los cambios: {cash_after:,} €.")

                candidates.append(Recommendation(
                    changes=changes, team=new_team, score=score, reasons=reasons
                ))

    # Mejor candidato por score, con preferencia por menos cambios en empate.
    candidates.sort(key=lambda x: (x.score, -len(x.changes)), reverse=True)
    return candidates
